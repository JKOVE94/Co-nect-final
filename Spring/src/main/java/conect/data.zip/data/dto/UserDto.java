package conect.data.dto;

import conect.data.entity.UserEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class UserDto {
    private Integer user_pk_num; // 사용자 사번
    private String user_id; // 사용자 아이디
    private String user_pw; // 사용자 패스워드
    private String user_name; // 사용자 이름
    private String user_mail; // 사용자 이메일
    private String user_pic; // 사용자 사진
    private Date user_lastlogin; // 사용자 마지막 로그인 일시
    private int user_trynum; // 사용자 로그인 시도 횟수
    private int user_locked; // 사용자 계정 잠김 여부
    private int user_author; // 사용자 권한
    private int user_istemppw; // 사용자 임시 비밀번호 여부
    private int user_fk_comp_num; // 사용자 회사 번호

    // Getters and Setters

    public static UserDto fromEntity(UserEntity user) {
        UserDto userDto = new UserDto();
        userDto.setUser_pk_num(user.getUserPkNum());
        userDto.setUser_id(user.getUserId());
        userDto.setUser_pw(user.getUserPw());
        userDto.setUser_name(user.getUserName());
        userDto.setUser_mail(user.getUserMail());
        userDto.setUser_pic(user.getUserPic());
        userDto.setUser_lastlogin(user.getUserLastlogin());
        userDto.setUser_trynum(user.getUserTrynum());
        userDto.setUser_locked(user.getUserLocked());
        userDto.setUser_author(user.getUserAuthor());
        userDto.setUser_istemppw(user.getUserIstemppw());
        userDto.setUser_fk_comp_num(user.getCompanyEntity().getCompPkNum());
        return userDto;
    }
}
